package com.saad.loganalyzer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogAnalyzerApplicationTests {

	@Test
	void contextLoads() {
	}

}
